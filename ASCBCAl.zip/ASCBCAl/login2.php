<?php

session_start();

    /*require_once "vendor/autoload.php";
    use Twilio\Rest\Client;
 
    $sid = "ACabe895127ac3ef8594c49431c5dc1ff7";
    $token = "095c5c7dd7964d770b65ae90448eab1d";
    */

    echo "<p>Can't go pass</p>";
    
    if (isset($_POST["login"]))
    {
        $username = $_POST["uname"];
        $password = $_POST["psw"];
        
        $conn = mysqli_connect("localhost", "root", "", "ascbcal");
        
        $sql = "SELECT * FROM users WHERE username = '$username'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0)
        {
            $row = mysqli_fetch_object($result);
            if (password_verify($password, $row->password))
            {
            /*  if ($row->is_tfa_enabled)
                {
                    $row->is_verified = false;
                    $_SESSION["user"] = $row;
 
                    $pin = rand(0, 9) . rand(0, 9) . rand(0, 9) . rand(0, 9) . rand(0, 9) . rand(0, 9);
                     
                    $sql = "UPDATE users SET pin = '$pin'  WHERE id = '" . $row->id . "'";
                    mysqli_query($conn, $sql);
 
                    $client = new Client($sid, $token);
                    $client->messages->create(
                        $row->phone, array(
                            "from" => '+14433414461',
                            "body" => "Your 2-factor authentication code is: ". $pin
                        )
                    );
 
                    header("Location: enter-pin.php");
                }
                else
                { */
                    $row->is_verified = true;
                    $_SESSION["user"] = $row;
                    $_SESSION["loggedin"] = true;
                    $_SESSION["id"] = $id;
                    $_SESSION["username"] = $username;

                      
                      header("Location: welcome.php");
                //}
                  }
                  else
                  {

                    echo '<script>alert("Wrong Password! Click OK to redirect back.");window.location = "index.php"; </script> ';
                }
            }
            else
            {
                echo '<script>alert("User does not exist. Click OK to redirect back.");window.location = "index.php"; </script> ';
            }
        }
        
        ?>