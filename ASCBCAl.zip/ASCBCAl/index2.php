

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
</head>

<body>
	<form action="twilio.php" method="post">
		<h2>HTML Form to Send SMS with Twillio</h2>
		Enter Mobile:<br>
		<input type="text" placeholder="Mobile Number" name="mobile"><br><br>
		Message<br>
		<textarea placeholder="Message" name="msg"></textarea><br><br>

		<input type="submit" value="Send">
	</form>
</body>
</html>






