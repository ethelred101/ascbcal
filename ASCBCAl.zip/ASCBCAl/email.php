
<?php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "GET") {

	$to_email = $_GET['mail'];
	$subject = $_GET['subject'];
	$body = $_GET['comment'];
	$headers = "From: sender\'s email";

	if (mail($to_email, $subject, $body, $headers)) {
		echo "Email successfully sent to $to_email...";
	} else {
		echo "Email sending failed...";
	}

}


?>