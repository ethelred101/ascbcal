<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  header("location: welcome.php");
  exit;
}

// Include config file
require_once "config.php";

// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = "";
?>

<html>


<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="manifest" href="manifest.json" />
  <link rel="icon" href="images/ascb.ico" type="image/x-icon" />  
  <link rel="apple-touch-icon" href="images/ascb3.png" />   
  <meta name="theme-color" content="white"/>  
  <meta name="apple-mobile-web-app-capable" content="yes"/>  
  <meta name="apple-mobile-web-app-status-bar-style" content="black"/> 
  <meta name="apple-mobile-web-app-title" content="ASCBCal"/> 
  <meta name="msapplication-TileImage" content="images/ascb2.png"/>  
  <meta name="msapplication-TileColor" content="#FFFFFF"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="js/indexJS.js"></script>
  

  <meta charset="utf-8">
  <title>ASCB Calendar of Activities</title>
  <link rel="stylesheet" href="css/indexStyle2.css">

  <link href="jquery.gcal_flow.css" rel="stylesheet" type="text/css">
  <script type="text/javascript" src="jquery.gcal_flow.js"></script>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>


<body>
  <script src="js/main.js"></script>

  <a href="javascript:void(0)" class="closebtn" id="closebtn" onclick="closeNav()"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></a>
  <a href="javascript:void(0)" class="openbtn" id="openbtn" onclick="openNav()"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></a>


  <nav id="mySidenav" class="sidenav">

    <div class="sideImg">
      <img src="images/ascb1.png" alt="Avatar" class="avatar">
    </div>

    <div class="navBtns">
      <a class="homebtn" href="#home"><i class="fa fa-home" aria-hidden="true"></i><span style="padding:10px">Home</span></a>

      <a class="calbtn" href="#calcont"><i class="fa fa-calendar" aria-hidden="true"></i><span style="padding:10px">Calendar</span></a>

      <a class="acadbtn" href="#acads"><i class="fa fa-book" aria-hidden="true"></i><span style="padding:10px">Academics</span></a>

      <a class="eventbtn" href="#eventcont"><i class="fa fa-flag" aria-hidden="true"></i><span style="padding:10px">Extracurricular</span></a>

      <a class="holibtn" href="#holidaycont"><i class="fa fa-globe" aria-hidden="true"></i><span style="padding:10px">Holidays</span></a>

      <a class="achbtn" href="#achievecont"><i class="fa fa-certificate" aria-hidden="true"></i><span style="padding:10px">Achievements</span></a>

    </div>

    <a onclick="document.getElementById('id04').style.display='block'" class="confbtn" style="margin-bottom:40px"><i class="fa fa-cogs" aria-hidden="true"></i><span style="padding:10px">Configurations</span></a>

    <a onclick="document.getElementById('id01').style.display='block'" class="loginbtn"><i class="fa fa-sign-in" aria-hidden="true"></i><span>Login</span></a>
    <a onclick="document.getElementById('id02').style.display='block'" class="loginbtn"><i class="fa fa-user-plus" aria-hidden="true"></i><span>Register</span></a>


  </nav>




  <!-- Log In Form -->

  <div id="id01" class="modal">
    <!-- Modal Content -->
    <form class="modal-content animate" method="POST" action="login2.php">
      <div class="imgcontainer">
        <img src="images/ascb1.png" alt="Avatar" class="avatar">
      </div>

      <div class="container">

        <div class="form-group">
          <label for="uname"><b>Username</b></label>
          <br>
          <input type="text" placeholder="Enter Username" name="uname" class="form-control" value="<?php echo $username; ?>" required>
        </div>


        <br>

        <div class="form-group">
         <label for="psw"><b>Password</b></label>
         <br>
         <input type="password" placeholder="Enter Password" name="psw" class="form-control" required>
       </div>

       <br>

       <div class="form-group">
        <button type="submit" class="btn btn-primary" name="login" value="Login">Log In</button>
      </div>

      <br>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" id="bottomCont" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div>

  </form>
</div>

<!-- Register Form -->

<div id="id02" class="modal">
  <!-- Modal Content -->
  <form class="modal-content animate" method="POST" action="register2.php">
    <div class="imgcontainer">
      <img src="images/ascb1.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="fullname"><b>Full Name</b></label>
      <br>
      <input type="fullname" placeholder="Enter Full Name" name="fullname" required>

      <br>

      <label for="uname"><b>Username</b></label>
      <br>
      <input type="username" placeholder="Enter Username" name="uname" required>

      <br>

      <label for="psw"><b>Password</b></label>
      <br>
      <input type="password" placeholder="Enter Password" name="psw" required>

      <br>

      <label for="phone"><b>Mobile Number</b></label>
      <br>

      <input type="text" placeholder="Enter Phone ex.(+631234567890)" name="phone">
      <br>

      <button type="submit" name="register">Register</button>
    </div>

    <div class="container" id="bottomCont" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn">Cancel</button>
    </div>

  </form>
</div>


<!-- Configurations Form -->

<div id="id04" class="modal">
  <form class="modal-content animate">
    <div class="form-group" style="padding-bottom: 10px">
      <p style="background-color:#d3d3d3">Only Registered Users Can Access the Configurations Tab</p>
    </div>
    

    <div class="container" id="bottomCont" style="background-color:#f1f1f1; padding-top: 10px;">
      <button type="button" onclick="document.getElementById('id04').style.display='none'" class="cancelbtn">Cancel</button>
    </div>


  </form>
  <div class="alert alert-info" style="display: none;"></div>
</div>




<!-- Parallax Content / Main Vertical Scrolling Content -->

<div id="parallaxCont" class="parallaxCont">

  <!-- Home -->
  <div id="homeCont">
    <script type="text/javascript">
      $(function autoVScroll(){
        var tickerLength = $('.vScrollCont ul li').length;
        var tickerHeight = $('.vScrollCont ul li').outerHeight();
        $('.vScrollCont ul li:last-child').prependTo('.vScrollCont ul');
        $('.vScrollCont ul').css('marginTop',-tickerHeight);

        function moveTop(){
          $('.vScrollCont ul').animate({
            top : -tickerHeight
          },600, function(){
           $('.vScrollCont ul li:first-child').appendTo('.vScrollCont ul');
           $('.vScrollCont ul').css('top','');
         });          
        }

        setInterval( function(){
          moveTop();
        }, 5000);

      });
    </script>

    <div class="vScroll">
      <div class="vScrollCont" id='vScroll'>


        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ascbcal";

// Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
        if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
        }
        $now = new DateTime(); 
        $nowStr = $now->format('Y-m-d H:i:s');

        $sql = "SELECT DISTINCT * FROM events WHERE (end_event >= '$nowStr')";
        $result = mysqli_query($conn, $sql);
        ?>
        <?php
        echo "<ul>";
        if (mysqli_num_rows($result) > 0) {
  // output data of each row
          while($row = mysqli_fetch_assoc($result)) {
            //echo "<h2>" . $row["title"] . "</h2>";    
            echo "<li>";
            if(("$nowStr" >= $row["start_event"]) && ("$nowStr" <= $row["end_event"])){
              echo "<h4 style='background-color:#FFB347'>" . $row["title"] . "</h4>";
            }else{
              echo "<h4>" . $row["title"] . "</h4>";
            }
            echo "<p id='firstP' style='font-size: 13px'>Start: ". $row["start_event"] . " / End: " . $row["end_event"] . "</p>";
            //echo "<p id='secondP'>" . $nowStr . "</p>";
            /*
            echo "<span id='deplvl' style='font-size: 13px; float: left; color:white'>Department Level: ". $row["level"] ."</span>";
            */
            echo "<div id='lvlCont'>";

            if($row["level"] == 'elem') {
              echo "<p id='deplvl' style='font-size: 13px; color:white'>Department Level:
              <br>Elementary </p> ";
            }else if($row["level"] == 'jhigh'){
              echo "<p id='deplvl' style='font-size: 13px; color:white'>Department Level: 
              <br>Junior HighSchool </p>";
            }else if($row["level"] == 'shigh'){
              echo "<p id='deplvl' style='font-size: 13px; color:white'>Department Level: 
              <br>Senior HighSchool </p>";
            }else if($row["level"] == 'elem jhigh'){
              echo "<p id='deplvl' style='font-size: 13px; color:white'>Department Level: 
              <br>Elementary and Junior HighSchool </p>";
            }else if($row["level"] == 'high'){
              echo "<p id='deplvl' style='font-size: 13px; color:white'>Department Level: 
              <br>Junior and Senior HighSchool </p>";
            }else if($row["level"] == 'elem high'){
              echo "<p id='deplvl' style='font-size: 13px; color:white'>Department Level:
              <br>Elementary, Junior Highschool and Senior HighSchool </p>";
            }else if($row["level"] == 'coll'){
              echo "<p id='deplvl' style='font-size: 13px; color:white'>Department Level: 
              <br>College </p>";
            }else if($row["level"] == 'newcoll'){
              echo "<p id='deplvl' style='font-size: 13px; color:white'>Department Level: 
              <br>College (New Curriculum) </p>";
            }else if($row["level"] == 'gradcoll'){
              echo "<p id='deplvl' style='font-size: 13px; color:white'>Department Level: 
              <br>College (Graduating) </p>";
            }else{
              echo "<p id='deplvl' style='font-size: 13px; color:white'>Department Level:
              <br>All </p>";
            }

            echo "<p id ='incharge' style='font-size: 13px; color:white'>Person In-Charge: 
            <br>".
            $row['incharge']
            ."</p>";

            echo "</div>";

            echo "</li>";
          }                                               

          echo "</ul>";
        } else {
          echo "There are currently no events fetched from the database!";
        }
        ?>
      </div>     
    </div>



    <?php
    mysqli_close($conn);
    ?>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ascbcal";

// Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }
    $now = new DateTime(); 
    $nowStr = $now->format('Y-m-d');

    $sql = "SELECT DISTINCT * FROM events WHERE (('$nowStr' <= end_event) && ('$nowStr' >= start_event)) LIMIT 3 ";
    $result = mysqli_query($conn, $sql);
    ?>

    <div class="topScroller">
      <?php
      echo "<div class='hScrolltext'>";
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          echo"<p style='float:left; margin-right:20px'>". $row["title"] ."</p>";
        }
      }
      else {
        echo"<p style='float:left; margin-right:20px'> Currently, there are no recent events.</p>";
      }
      echo "</div>";
      ?>
    </div>

    <?php
    mysqli_close($conn);
    ?>

    <div class="slideCont">
      <?php
      $servername = "localhost";
      $username = "root";
      $password = "";
      $dbname = "ascbcal";
      $conn = mysqli_connect($servername, $username, $password, $dbname);
      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
      }

      $sql = "SELECT DISTINCT * FROM achievements";

      $result = mysqli_query($conn, $sql);
      ?>
      <?php
      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          echo '<span class = "slidelvl" >'. $row['level'] .'</span>';
          echo '<img class = "slidey" id = "slidey" src="data:image/jpeg;base64,'. base64_encode( $row['ach_img'] ).'"/>';
          echo '<span class = "slidesc" >'. $row['achieve_desc'] .'</span>';
        }
      }
      mysqli_close($conn);
      ?>
      <!--
      <img class="slidey" src="images/img1.jpg">
      <img class="slidey" src="images/img2.jpg">
      <img class="slidey" src="images/img3.jpg">
    -->
  </div>

</div>
<div class="home" id="home">
</div>



<!-- Calendar -->

<div style="color: #777;background-color:white;text-align:center;padding:50px 80px;text-align: justify;">
  <h3 style="text-align:center;"><i class="fa fa-calendar" aria-hidden="true"></i>Calendar Of Activities</h3>
  <p></p>
</div>

<div class="cal" id="cal">

</div>
<div class="calcont" id="calcont" style="z-index: -1">
  <embed type="text/html" src="dist/index.php"  width="100%" height="100%">
  </div>

  <!-- Academics -->
  <div style="position:relative;">
    <div style="color:#777;background-color:white;text-align:center;padding:50px 80px;text-align: justify;">
      <h3 style="text-align:center;"><i class="fa fa-book" aria-hidden="true"></i>Academics</h3>
    </div>
  </div>

  <div class="acadcont">

  </div>

  <div class="acads" id="acads">
   <embed type="text/html" src="dist/news-article/index.html"  width="100%" height="100%">     
   </div>

   <!-- Events -->
   <div style="position:relative;">
    <div style="color:#777;background-color:white;text-align:center;padding:50px 80px;text-align: justify;">
      <h3 style="text-align:center;"><i class="fa fa-flag" aria-hidden="true"></i>Extracurricular</h3>
    </div>
  </div>

  <div class="eventcont" id="eventcont">

  </div>

  <div class="events">
    <embed type="text/html" src="dist/news-article/index2.html"  width="100%" height="100%">
    </div>

    <!-- Holidays -->
    <div style="position:relative;">
      <div style="color:#777;background-color:white;text-align:center;padding:50px 80px;text-align: justify;">
        <h3 style="text-align:center;"><i class="fa fa-globe" aria-hidden="true"></i>Holidays</h3>
      </div>
    </div>

    <div class="holidaycont" id="holidaycont">

    </div>

    <div class="holidays">
      <embed type="text/html" src="dist/news-article/reader/holiday.php"  width="100%" height="100%">
      </div>

      <!-- Achievements Tab-->

      <div style="position:relative;">
        <div style="color:#777;background-color:white;text-align:center;padding:50px 80px;text-align: justify;">
          <h3 style="text-align:center;"><i class="fa fa-certificate" aria-hidden="true"></i>Achievements</h3>
        </div>
      </div>

      <div class="achievecont" id="achievecont">

      </div>

      <div class="achievements">
        <embed type="text/html" src="dist/news-article/reader/achieve2.php"  width="100%" height="100%">
        </div>







      </div>



      <script>
        var myIndex = 0;
        carousel();

        function carousel() {
          var i;
          var x = document.getElementsByClassName("slidey");
          var y = document.getElementsByClassName("slidesc");
          var z = document.getElementsByClassName("slidelvl");
          for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
            y[i].style.display = "none";
            z[i].style.display = "none";   
          }
          myIndex++;
          if (myIndex > x.length) {myIndex = 1}    
            x[myIndex-1].style.display = "block"; 
            y[myIndex-1].style.display = "block"; 
            z[myIndex-1].style.display = "block"; 
            setTimeout(carousel, 5000); // Change image every 2 seconds
          }
        </script>




      </body>

      </html>