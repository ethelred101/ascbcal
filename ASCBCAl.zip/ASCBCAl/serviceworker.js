const cacheName = "ASCBCalendar";
const filesToCache = [
  "/",
  "/index.php",
  "/welcome.php",
  "/app.js",
  "css/indexStyle2.css",
  "images/campus.jpg",
];

/* Start the service worker and cache all of the app's content */
self.addEventListener("install", installEvent => {
  installEvent.waitUntil(
    caches.open(cacheName).then(cache => {
      cache.addAll(filesToCache)
    })
  )
});

/* Serve cached content when offline */
self.addEventListener("fetch", fetchEvent => {
  fetchEvent.respondWith(
    caches.match(fetchEvent.request).then(res => {
      return res || fetch(fetchEvent.request)
    })
  )
});


