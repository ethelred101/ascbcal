function openNav() {
	document.getElementById("mySidenav").style.width = "250px";
	document.getElementById("parallaxCont").style.marginLeft = "250px";
	document.getElementById("closebtn").style.left = "250px";

}

function closeNav() {
	document.getElementById("mySidenav").style.width = "0";
	document.getElementById("parallaxCont").style.marginLeft = "0";
	document.getElementById("closebtn").style.left = "0";

}


var mq = window.matchMedia( "(max-width: 480px)" );
if (mq.matches) {
	window.onload = function closeNav(){
		document.getElementById("mySidenav").style.width = "0";
		document.getElementById("parallaxCont").style.marginLeft = "0";
		document.getElementById("closebtn").style.left = "0";
	}
}
else {
	window.onload = function openNav(){
		document.getElementById("mySidenav").style.width = "250px";
		document.getElementById("parallaxCont").style.marginLeft = "250px";
		document.getElementById("closebtn").style.left = "250px"
		
	}
}

var $ = jQuery;

$(document).ready(function (){
	$(".navBtns a").click(function( e ) {
		e.preventDefault();

		if(this.hash){

			var target = '#'+ this.hash.substr(1);
			var destination = $(target).offset().top - 10;

			$('html, body').stop().animate({
				scrollTop : '+=' + destination
			}, 2000);
		}
	});	

});


/*
$(document).ready(function (){
	$(".homebtn").click(function (){
		$('html, body').animate({
			scrollTop: $(".home").offset().top
		}, 2000);
	});
});


$(document).ready(function (){
	$(".calbtn").click(function (){
		$('html, body').animate({
			scrollTop: $(".calcont").offset().top
		}, 2000);
	});
});

$(document).ready(function (){
	$(".acadbtn").click(function (){
		$('html, body').animate({
			scrollTop: $(".acads").offset().top
		}, 2000);
	});
});

$(document).ready(function (){
	$(".eventbtn").click(function (){
		$('html, body').animate({
			scrollTop: $(".eventcont").offset().top
		}, 2000);
	});
});

$(document).ready(function (){
	$(".contbtn").click(function (){
		$('html, body').animate({
			scrollTop: $(".contscont").offset().top
		}, 2000);
	});
});
*/





$(function() {
	$('#gcf-design').gCalFlow({
		calid: 'en.philippines%23holiday@group.v.calendar.google.com',
		maxitem: 10
	});
});



var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
	if (event.target == modal) {
		modal.style.display = "none";
	}
}

$(function(){
	$('#logout').click(function(){
		if(confirm('Are you sure to logout?')) {
			return true;
		}

		return false;
	});
});

jQuery.fn.liScroll = function(settings) {
	settings = jQuery.extend({
		travelocity: 0.03
	}, settings);		
	return this.each(function(){
		var $strip = jQuery(this);
		$strip.addClass("newsticker")
		var stripHeight = 1;
		$strip.find("li").each(function(i){
					stripHeight += jQuery(this, i).outerHeight(true); // thanks to Michael Haszprunar and Fabien Volpi
				});
		var $mask = $strip.wrap("<div class='mask'></div>");
		var $tickercontainer = $strip.parent().wrap("<div class='tickercontainer'></div>");								
				var containerHeight = $strip.parent().parent().height();	//a.k.a. 'mask' width 	
				$strip.height(stripHeight);			
				var totalTravel = stripHeight;
				var defTiming = totalTravel/settings.travelocity;	// thanks to Scott Waye		
				function scrollnews(spazio, tempo){
					$strip.animate({top: '-='+ spazio}, tempo, "linear", function(){$strip.css("top", containerHeight); scrollnews(totalTravel, defTiming);});
				}
				scrollnews(totalTravel, defTiming);				
				$strip.hover(function(){
					jQuery(this).stop();
				},
				function(){
					var offset = jQuery(this).offset();
					var residualSpace = offset.top + stripHeight;
					var residualTime = residualSpace/settings.travelocity;
					scrollnews(residualSpace, residualTime);
				});			
			});		
};

$(function(){
	$("ul#ticker01").liScroll();
});

_gCalFlow_debug = true;



