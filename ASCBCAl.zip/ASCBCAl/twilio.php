<?php
include './vendor/autoload.php';

use Twilio\Rest\Client;

if(isset($_POST['mobile'])) {
	//twillio
	$sid = getenv('ACf0dd874ffd6d048fa1afbbf5ac9755ca');                                   
	//'ACabe895127ac3ef8594c49431c5dc1ff7';
	$token = getenv('b23146547b046c3708af78bee01da2b6');                                   
	//'095c5c7dd7964d770b65ae90448eab1d';
	$twilio = new Client($sid, $token);

	/*$message = $twilio->messages
	->create(
		$_POST['mobile'], array(
			"from"=> "+14433414461",
			"body" => $_POST['msg']

		)
	);*/

	$verification = $twilio->verify->v2->services("VAc1b761da2f69a5943a487f076de36093")
                                   ->verifications
                                   ->create($_POST['mobile'], "sms");
    /*$verification_check = $twilio->verify->v2->services("VAc1b761da2f69a5943a487f076de36093")
                                         ->verificationChecks
                                         ->create("123456", // code
                                                  array("to" => "+15017122661")
                                         );*/

	/*if($message->sid){
		echo "Message sent!";
	}*/
	/*if($verification->status){

	}*/
	print($verification->sid);
	//print($verification_check->status);
}

?>
