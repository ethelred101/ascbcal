

<form method="POST" action="enter-pin.php">
	<input type="text" name="pin">
	
	<input type="submit" name="enter_pin">
</form>

<?php

session_start();

if (isset($_POST["enter_pin"]))
{
	$pin = $_POST["pin"];
	$user_id = $_SESSION["user"]->id;
	$_SESSION["id"] = $id;
	$_SESSION["username"] = $username;
	
	$conn = mysqli_connect("localhost", "root", "", "ascbcal");
	
	$sql = "SELECT * FROM users WHERE id = '$user_id' AND pin = '$pin'";
	$result = mysqli_query($conn, $sql);
	
	if (mysqli_num_rows($result) > 0)
	{
		$sql = "UPDATE users SET pin = '' WHERE id = '$user_id'";
		mysqli_query($conn, $sql);
		
		$_SESSION["user"]->is_verified = true;
		$_SESSION["loggedin"] = true;


		header("Location: welcome.php");
	}
	else
	{
		echo "Wrong pin";
	}
}

?>