window.onload = () => {
  'use strict';

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker
             .register('./serviceworker.js');            
  }
$('.toggle').click(function(e){
    $('.main').slideToggle();
});

if ('serviceWorker' in navigator) {
navigator.serviceWorker.register('./serviceworker.js').
    then(function (registration) {
        // Registration was successful``
        console.log('ServiceWorker registration successful with scope: ', 
registration.scope);
    }).catch(function (err) {
        // registration failed :(
        console.log('ServiceWorker registration failed: ', err);
    });

    navigator.serviceWorker.getRegistrations()
        .then(function(registrations) {
            for(let registration of registrations) {
               if(registration.active.scriptURL == 'http://localhost/ASCBCAl/serviceworker.js'){ registration.unregister(); }
            }
        });
}
}
//--------------//



