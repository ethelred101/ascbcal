<?php
 
    if (isset($_POST["register"]))
    {
        $username = $_POST["uname"];
        $fullname = $_POST["fullname"];
        $phone = $_POST["phone"];
        $password = $_POST["psw"];
        $password = password_hash($password, PASSWORD_DEFAULT);
 
        $conn = mysqli_connect("localhost", "root", "", "ascbcal");
         
        $sql = "INSERT INTO users (username, full_name, phone, password, is_tfa_enabled, pin) VALUES ('$username', '$fullname', '$phone', '$password', 0, '')";
        mysqli_query($conn, $sql);
 
        header("Location: index.php");
    }
 
?>