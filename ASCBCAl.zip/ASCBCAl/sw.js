var cacheName = 'ASCBCalendar';
var filestocache = [
  '/',
  'index.php',
  'welcome.php',
  'login2.php',
  'register2.php',
  'logout.php',
  'js/main.js',
  'manifest.json',
  'images/ascb.ico'
];

/* Start the service worker and cache all of the app's content */
self.addEventListener("install", function(e) {
  e.waitUntil(
    caches.open("ASCBCalendar").then(function(cache) {
      return cache.addAll(filestocache);
    })
  );
});

/* Serve cached content when offline 
self.addEventListener("fetch", function(e) {
  e.respondWith(
    caches.match(e.request).then(function(response) {
      return response || fetch(e.request);
    })
  );
});
*/

self.addEventListener("fetch", function(e) {
    e.respondWith(
        fetch(e.request).catch(function() {
            return caches.match(e.request)
        })
    )
});
